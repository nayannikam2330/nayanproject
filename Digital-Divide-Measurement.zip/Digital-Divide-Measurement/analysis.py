from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

BASE_DIR = Path(__file__).resolve().parent
CHART_DIR = BASE_DIR / "charts"
CHART_DIR.mkdir(exist_ok=True)

def make_charts(df):
    if df.empty:
        return {}
    sns.set_theme(style="whitegrid")
    for p in CHART_DIR.glob("*.png"):
        p.unlink()
    charts = {}

    plt.figure(figsize=(7,4))
    df.groupby("location")["digital_divide_score"].mean().plot(kind="bar")
    plt.title("Average Digital Divide Score: Rural vs Urban")
    plt.ylabel("Score (0-100)")
    plt.tight_layout(); path=CHART_DIR/"rural_urban_score.png"; plt.savefig(path,dpi=130); plt.close()
    charts["rural_urban_score"] = "rural_urban_score.png"

    plt.figure(figsize=(7,4))
    plt.hist(df["digital_divide_score"], bins=10)
    plt.title("Digital Divide Score Distribution"); plt.xlabel("Score"); plt.ylabel("Respondents")
    plt.tight_layout(); path=CHART_DIR/"score_distribution.png"; plt.savefig(path,dpi=130); plt.close()
    charts["score_distribution"] = "score_distribution.png"

    plt.figure(figsize=(7,4))
    pd.crosstab(df["location"], df["internet_access"], normalize="index").mul(100).plot(kind="bar", stacked=True)
    plt.title("Internet Access by Location"); plt.ylabel("Percentage"); plt.legend(title="Access")
    plt.tight_layout(); path=CHART_DIR/"internet_access_location.png"; plt.savefig(path,dpi=130); plt.close()
    charts["internet_access_location"] = "internet_access_location.png"

    plt.figure(figsize=(6,4))
    df["smartphone"].value_counts().plot(kind="pie", autopct="%1.1f%%", ylabel="")
    plt.title("Smartphone Ownership"); plt.tight_layout()
    path=CHART_DIR/"smartphone.png"; plt.savefig(path,dpi=130); plt.close(); charts["smartphone"]="smartphone.png"

    plt.figure(figsize=(6,4))
    df["computer"].value_counts().plot(kind="pie", autopct="%1.1f%%", ylabel="")
    plt.title("Computer/Laptop Ownership"); plt.tight_layout()
    path=CHART_DIR/"computer.png"; plt.savefig(path,dpi=130); plt.close(); charts["computer"]="computer.png"

    edu = df.groupby("education")["digital_literacy"].apply(lambda s: (s=="High").mean()*100).sort_values()
    plt.figure(figsize=(8,4)); edu.plot(kind="barh")
    plt.title("High Digital Literacy by Education"); plt.xlabel("Percentage")
    plt.tight_layout(); path=CHART_DIR/"literacy_education.png"; plt.savefig(path,dpi=130); plt.close()
    charts["literacy_education"]="literacy_education.png"

    usage = pd.crosstab(df["age_group"], df["internet_usage"]).reindex(index=sorted(df["age_group"].unique()), fill_value=0)
    usage.plot(kind="bar", figsize=(9,4))
    plt.title("Internet Usage by Age Group"); plt.ylabel("Respondents")
    plt.tight_layout(); path=CHART_DIR/"usage_age.png"; plt.savefig(path,dpi=130); plt.close()
    charts["usage_age"]="usage_age.png"

    income_order = ["Below 10000","10000-25000","25001-50000","50001-100000","Above 100000"]
    inc = df.groupby("income")["digital_divide_score"].mean().reindex(income_order)
    plt.figure(figsize=(8,4)); inc.plot(kind="bar")
    plt.title("Average Digital Divide Score by Income"); plt.ylabel("Score")
    plt.xticks(rotation=25); plt.tight_layout(); path=CHART_DIR/"score_income.png"; plt.savefig(path,dpi=130); plt.close()
    charts["score_income"]="score_income.png"

    plt.figure(figsize=(8,4))
    df["barrier"].value_counts().sort_values().plot(kind="barh")
    plt.title("Main Barriers to Digital Access"); plt.xlabel("Respondents")
    plt.tight_layout(); path=CHART_DIR/"barriers.png"; plt.savefig(path,dpi=130); plt.close()
    charts["barriers"]="barriers.png"

    plt.figure(figsize=(7,4))
    pd.crosstab(df["location"], df["category"], normalize="index").mul(100).plot(kind="bar")
    plt.title("Digital Divide Category by Location"); plt.ylabel("Percentage")
    plt.xticks(rotation=0); plt.tight_layout(); path=CHART_DIR/"category_location.png"; plt.savefig(path,dpi=130); plt.close()
    charts["category_location"]="category_location.png"
    return charts
