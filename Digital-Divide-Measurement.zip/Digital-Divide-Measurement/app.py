from pathlib import Path
from io import BytesIO
import pandas as pd
from flask import Flask, render_template, request, redirect, url_for, session, flash, send_file, send_from_directory
from database import init_db, insert_response, fetch_all, delete_response, replace_from_dataframe
from preprocessing import preprocess_dataframe, calculate_score, category
from analysis import make_charts
from ml_model import train_model

BASE_DIR = Path(__file__).resolve().parent
app = Flask(__name__)
app.secret_key = "digital-divide-academic-demo-secret-key"
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024

ADMIN_USER = "admin"
ADMIN_PASSWORD = "admin123"

init_db()

def dataframe_from_db():
    rows = fetch_all()
    return pd.DataFrame(rows)

def refresh_outputs():
    df = dataframe_from_db()
    if not df.empty:
        make_charts(df)
    return df

@app.context_processor
def inject_globals():
    return {"project_title":"Digital Divide Measurement Analysis"}

@app.route("/")
def index():
    df=refresh_outputs()
    stats={"total":len(df),
           "avg":round(df["digital_divide_score"].mean(),2) if not df.empty else 0,
           "rural":round(df.loc[df.location=="Rural","digital_divide_score"].mean(),2) if not df.empty and (df.location=="Rural").any() else 0,
           "urban":round(df.loc[df.location=="Urban","digital_divide_score"].mean(),2) if not df.empty and (df.location=="Urban").any() else 0}
    return render_template("index.html", stats=stats)

@app.route("/survey", methods=["GET","POST"])
def survey():
    if request.method=="POST":
        data=request.form.to_dict()
        score=calculate_score(data)
        cat=category(score)
        insert_response(data,score,cat)
        refresh_outputs()
        flash(f"Survey submitted successfully. Digital Divide Score: {score:.1f}/100", "success")
        return redirect(url_for("dashboard"))
    return render_template("survey.html")

@app.route("/dashboard")
def dashboard():
    df=refresh_outputs()
    if df.empty:
        return render_template("dashboard.html", empty=True)
    stats={
        "total":len(df),
        "avg":round(df.digital_divide_score.mean(),2),
        "rural":round(df.loc[df.location=="Rural","digital_divide_score"].mean(),2),
        "urban":round(df.loc[df.location=="Urban","digital_divide_score"].mean(),2),
        "internet":round((df.internet_access!="No").mean()*100,1),
        "smartphone":round((df.smartphone=="Yes").mean()*100,1),
        "computer":round((df.computer=="Yes").mean()*100,1),
        "literacy":round((df.digital_literacy=="High").mean()*100,1),
        "high_divide":round((df.category=="High Digital Divide / Low Digital Inclusion").mean()*100,1)
    }
    return render_template("dashboard.html", stats=stats, charts=list((BASE_DIR/"charts").glob("*.png")))

@app.route("/analysis")
def analysis_page():
    df=refresh_outputs()
    result=None
    if not df.empty:
        result=train_model(df)
    return render_template("analysis.html", result=result)

@app.route("/rural-urban")
def rural_urban():
    df=refresh_outputs()
    if df.empty: return render_template("rural_urban.html", empty=True)
    summary=[]
    for loc in ["Rural","Urban"]:
        x=df[df.location==loc]
        if len(x):
            summary.append({"location":loc,"count":len(x),"score":round(x.digital_divide_score.mean(),2),
                            "internet":round((x.internet_access!="No").mean()*100,1),
                            "smartphone":round((x.smartphone=="Yes").mean()*100,1),
                            "computer":round((x.computer=="Yes").mean()*100,1),
                            "literacy":round((x.digital_literacy=="High").mean()*100,1),
                            "skills":round((x.digital_skills=="High").mean()*100,1),
                            "services":round((x.online_services=="Yes").mean()*100,1),
                            "barrier":x.barrier.value_counts().idxmax()})
    return render_template("rural_urban.html", summary=summary)

@app.route("/upload", methods=["GET","POST"])
def upload():
    if not session.get("admin"): return redirect(url_for("login"))
    if request.method=="POST":
        f=request.files.get("file")
        if not f or not f.filename.lower().endswith(".csv"):
            flash("Please select a CSV file.", "danger"); return redirect(url_for("upload"))
        try:
            df=preprocess_dataframe(pd.read_csv(f))
            replace_from_dataframe(df)
            df.to_csv(BASE_DIR/"data"/"processed_data.csv", index=False)
            make_charts(df)
            train_model(df)
            flash(f"Uploaded and processed {len(df)} survey records.", "success")
            return redirect(url_for("admin"))
        except Exception as e:
            flash(str(e), "danger")
    return render_template("upload.html")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        if request.form.get("username")==ADMIN_USER and request.form.get("password")==ADMIN_PASSWORD:
            session["admin"]=True; return redirect(url_for("admin"))
        flash("Invalid admin credentials.", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear(); return redirect(url_for("index"))

@app.route("/admin")
def admin():
    if not session.get("admin"): return redirect(url_for("login"))
    return render_template("admin.html", rows=fetch_all())

@app.route("/admin/delete/<int:row_id>")
def admin_delete(row_id):
    if not session.get("admin"): return redirect(url_for("login"))
    delete_response(row_id); flash("Record deleted.", "success"); return redirect(url_for("admin"))

@app.route("/download/csv")
def download_csv():
    df=dataframe_from_db()
    if df.empty: df=pd.read_csv(BASE_DIR/"data"/"sample_survey_data.csv")
    bio=BytesIO(); df.to_csv(bio,index=False); bio.seek(0)
    return send_file(bio, mimetype="text/csv", as_attachment=True, download_name="survey_data.csv")

@app.route("/download/processed")
def download_processed():
    p=BASE_DIR/"data"/"processed_data.csv"
    if not p.exists(): refresh_outputs().to_csv(p,index=False)
    return send_from_directory(p.parent,p.name,as_attachment=True)

@app.route("/download/report")
def download_report():
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet
    df=dataframe_from_db()
    if df.empty: df=pd.read_csv(BASE_DIR/"data"/"sample_survey_data.csv")
    out=BytesIO()
    doc=SimpleDocTemplate(out,pagesize=A4)
    styles=getSampleStyleSheet(); story=[Paragraph("Digital Divide Measurement Analysis",styles["Title"]),
        Paragraph("Survey Data Analysis Report",styles["Heading2"]), Spacer(1,12)]
    story.append(Paragraph(f"Total respondents: {len(df)}",styles["BodyText"]))
    story.append(Paragraph(f"Average Digital Divide Score: {df.digital_divide_score.mean():.2f}/100",styles["BodyText"]))
    for loc in ["Rural","Urban"]:
        x=df[df.location==loc]
        if len(x): story.append(Paragraph(f"{loc}: average score {x.digital_divide_score.mean():.2f}; internet access {(x.internet_access!='No').mean()*100:.1f}%",styles["BodyText"]))
    story.append(Spacer(1,10))
    story.append(Paragraph("Interpretation",styles["Heading2"]))
    story.append(Paragraph("Higher scores indicate stronger digital inclusion and lower digital divide. Scores below 40 indicate high digital divide, 40-69 moderate divide, and 70-100 low divide/high inclusion.",styles["BodyText"]))
    table_data=[["Category","Respondents"]]+[[str(k),str(v)] for k,v in df.category.value_counts().items()]
    t=Table(table_data); t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.lightgrey),("GRID",(0,0),(-1,-1),0.5,colors.grey)])); story += [Spacer(1,12),t]
    doc.build(story); out.seek(0)
    return send_file(out,mimetype="application/pdf",as_attachment=True,download_name="digital_divide_report.pdf")

@app.route("/charts/<path:filename>")
def chart_file(filename):
    return send_from_directory(BASE_DIR/"charts",filename)

@app.errorhandler(404)
def not_found(e): return render_template("404.html"),404

if __name__=="__main__":
    # Seed the database with sample data only when it is empty.
    if not fetch_all():
        sample=pd.read_csv(BASE_DIR/"data"/"sample_survey_data.csv")
        replace_from_dataframe(sample)
    refresh_outputs()
    print("Running at http://127.0.0.1:5000")
    app.run(debug=True)
