# Digital Divide Measurement Analysis using Survey Data

A beginner-friendly TY Data Science academic project built with Flask, SQLite, Pandas, NumPy, Scikit-learn, Matplotlib and Seaborn.

## Objective
Measure digital inclusion and the digital divide using survey variables covering device access, internet availability and quality, digital literacy, skills and online services. The project compares rural and urban groups and provides a simple Decision Tree prediction model.

## Score methodology
The **Digital Divide Score is actually an inclusion score**: higher values mean better digital inclusion and therefore a lower digital divide.

Maximum = 100:
- Smartphone = 15
- Computer/Laptop = 10
- Internet availability = 20
- Internet quality = 10
- Digital literacy = 10
- Digital skills = 10
- Online banking = 3
- Online education = 3
- Online government services = 3
- Social media = 2
- Internet cost = 4

Classification:
- 0–39: High Digital Divide / Low Digital Inclusion
- 40–69: Moderate Digital Divide
- 70–100: Low Digital Divide / High Digital Inclusion

## Features
- Survey collection
- SQLite storage
- Automatic score calculation
- Dashboard KPIs
- 10 data visualizations
- Rural vs urban comparison
- CSV upload and preprocessing
- Decision Tree classifier
- Accuracy, classification report and confusion matrix
- CSV downloads
- PDF report
- Admin login and record deletion

## Run in VS Code
1. Extract the ZIP.
2. Open the `Digital-Divide-Measurement` folder in VS Code.
3. Open Terminal.
4. Optional: create a virtual environment:
   `python -m venv .venv`
5. Activate it on Windows:
   `.venv\Scripts\activate`
6. Install packages:
   `pip install -r requirements.txt`
7. Run:
   `python app.py`
8. Open:
   `http://127.0.0.1:5000`

## Demo admin credentials
Username: `admin`
Password: `admin123`

Change the credentials in `app.py` before any real deployment.

## CSV columns
age_group, gender, location, education, employment, income, smartphone, computer, internet_access, internet_quality, internet_usage, digital_literacy, online_banking, online_education, online_services, social_media, internet_cost, digital_skills, barrier

## Project structure
- `app.py` - Flask routes and web application
- `database.py` - SQLite functions
- `preprocessing.py` - cleaning and score calculation
- `analysis.py` - chart generation
- `ml_model.py` - Decision Tree model
- `data/` - sample and processed datasets
- `templates/` - HTML pages
- `static/` - CSS and JavaScript
- `charts/` - generated charts
- `models/` - trained model

## Viva points
The project follows: Data Collection -> Preprocessing -> Feature Scoring -> Exploratory Analysis -> Rural/Urban Comparison -> Visualization -> Classification -> Reporting.

## Important note
This is an academic demonstration project. The sample dataset contains synthetic records and no real personal information.
